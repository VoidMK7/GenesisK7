# NovaTrade static frontend — Vercel deployment fix

This is a static HTML/CSS/JavaScript frontend, not a Next.js app.
The package.json and build script make Vercel build it into `dist/`.

## Vercel settings

In Project → Settings → Build and Deployment:

- Framework Preset: **Other**
- Root Directory: the folder containing `index.html` and this `package.json`
- Build Command: `npm run build`
- Output Directory: `dist`
- Install Command: leave default (there are no external dependencies)

Do not configure `next build` for this static frontend.

## Important

This package.json fixes the build configuration only. It does not add a Supabase backend,
authentication, live market data, broker connections, or trading execution.
Those require separate implementation and secure server-side integrations.
