import { cp, mkdir, readdir } from "node:fs/promises";
import path from "node:path";

const root = process.cwd();
const output = path.join(root, "dist");

await mkdir(output, { recursive: true });

for (const entry of await readdir(root, { withFileTypes: true })) {
  if (entry.name === "dist" || entry.name === "node_modules" ||
      entry.name === ".git" || entry.name === "scripts" ||
      entry.name === "package.json") continue;

  await cp(path.join(root, entry.name), path.join(output, entry.name), {
    recursive: true
  });
}

console.log("Static NovaTrade frontend copied to dist/");
